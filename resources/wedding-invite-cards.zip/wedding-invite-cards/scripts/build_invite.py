#!/usr/bin/env python3
"""Build an interactive wedding invite from a JSON config.

usage: python3 build_invite.py config.json OUT_DIR [--inline]

OUT_DIR gets index.html + img/. With --inline every image is embedded as a
data URI, so OUT_DIR/index.html is one self-contained file (best for
claude.ai artifacts, WhatsApp/email attachments, or Netlify Drop).
Config format: see references/config.md. Stdlib only; Pillow or macOS `sips`
is used for resizing photos when available.
"""
import base64, datetime as dt, html, json, mimetypes, re, shutil, subprocess, sys, urllib.parse
from pathlib import Path

SKILL = Path(__file__).resolve().parent.parent
ASSETS = SKILL / "assets"

THEMES = {
    "royal-rose": dict(tokens="--paper:#f4e9ed;--blush:#ead7df;--pearl:#fcf7f5;--ink:#4a2c40;--mauve:#86607a;--rose:#9c2f52;--rose-lt:#b13a62;--wine:#6e1b38;--gold:#b08a52;--gold-lt:#e6cc93;--glow:244,233,237;--glow2:252,247,245",
                       hue=345, petal=["#f2b8c6", "#e993ab", "#f7d2dc", "#c75b7a", "#f4c2cf"], heart=["#c2456d", "#e993ab", "#9c2f52"],
                       invocation="॥ श्री गणेशाय नमः ॥", blessing="शुभ विवाह", greeting="Namaste!"),
    "temple-gold": dict(dark=True, tokens="--paper:#f6ecdc;--blush:#ecd9bd;--pearl:#fff8ec;--ink:#3d1a12;--mauve:#7a4a32;--rose:#8c1c24;--rose-lt:#a8323a;--wine:#5c0f16;--gold:#b8862f;--gold-lt:#f0cf7a;--glow:255,246,228;--glow2:255,250,240",
                        hue=42, petal=["#fffaf0", "#fff3d6", "#f5e6c8", "#ffffff", "#ffe9a8"], heart=["#a8323a", "#d4a24a", "#8c1c24"],
                        invocation="॥ श्री गणेशाय नमः ॥", blessing="Subha Muhurtham", greeting="Namaskaram!"),
    "bengal-red": dict(tokens="--paper:#fbf6ef;--blush:#f1e2d3;--pearl:#fffdf8;--ink:#3a1410;--mauve:#8a4a3a;--rose:#b3121f;--rose-lt:#d42a33;--wine:#7a0a12;--gold:#b8862f;--gold-lt:#efd08a;--glow:255,251,244;--glow2:255,253,248",
                       hue=358, petal=["#d42a33", "#ffffff", "#f6c9c4", "#b3121f", "#fde7e4"], heart=["#d42a33", "#b3121f", "#f6c9c4"],
                       invocation="॥ শ্রী শ্রী প্রজাপতয়ে নমঃ ॥", blessing="শুভ বিবাহ", greeting="Nomoskar!"),
    "phulkari": dict(dark=True, tokens="--paper:#fff3e6;--blush:#ffd9c2;--pearl:#fffaf4;--ink:#3f1033;--mauve:#8a3d6e;--rose:#c2185b;--rose-lt:#e0407a;--wine:#7b0f45;--gold:#d9820f;--gold-lt:#ffd36b;--glow:255,243,230;--glow2:255,250,244",
                     hue=32, petal=["#ff9f1c", "#ffbf3c", "#ff7a00", "#ffd36b", "#f25c05"], heart=["#e0407a", "#c2185b", "#ff9f1c"],
                     invocation="ੴ", blessing="ਸ਼ੁਭ ਵਿਆਹ", greeting="Sat Sri Akal!"),
    "emerald-nikah": dict(dark=True, tokens="--paper:#eef3ee;--blush:#d6e4da;--pearl:#fbfcf8;--ink:#12302a;--mauve:#4f6f62;--rose:#0f5c4a;--rose-lt:#1f7a62;--wine:#0a3d32;--gold:#b8964f;--gold-lt:#ecd49a;--glow:240,246,240;--glow2:251,252,248",
                          hue=45, petal=["#ffffff", "#f3e3c3", "#e8d1a0", "#f7f0e0", "#d9c08a"], heart=["#1f7a62", "#b8964f", "#0f5c4a"],
                          invocation="بِسْمِ ٱللَّٰهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ", blessing="Nikah Mubarak", greeting="Assalamu alaikum!"),
    "ivory-minimal": dict(tokens="--paper:#f7f4ee;--blush:#ebe6dc;--pearl:#fdfcf9;--ink:#2c2a26;--mauve:#7a756b;--rose:#5f6f52;--rose-lt:#7a8b6b;--wine:#3f4a36;--gold:#a8894f;--gold-lt:#e3cf9f;--glow:247,244,238;--glow2:253,252,249",
                          hue=95, petal=["#ffffff", "#e9e4d8", "#cfd8c4", "#a8b59a", "#f3efe6"], heart=["#7a8b6b", "#a8894f", "#5f6f52"],
                          invocation="", blessing="Together forever", greeting="Hello!"),
}

DARK_GATE = ("#gate .top,#gate .hint,#gate .rhint{background:radial-gradient(60% 70% at 50% 50%,rgba(0,0,0,.5),rgba(0,0,0,0))}"
             "#gate .top .t,#gate .hint b,#gate .rhint b{color:var(--gold-lt)}#gate .top .sub,#gate .hint span,#gate .rhint span{color:var(--pearl)}")

# event card colours by keyword: (tint, art gradient, chip)
EVENT_LOOKS = [
    (("haldi", "pithi", "mayun", "gaye holud"), ("#ffd968", "linear-gradient(160deg,#ffd95e,#ee9b17)", "#f6c533")),
    (("mehendi", "mehndi", "mehandi"), ("#b9dc8f", "linear-gradient(160deg,#9fd16a,#3f8a3a)", "linear-gradient(135deg,#5aa646 50%,#f2c14e 50%)")),
    (("sangeet", "cocktail", "dandiya", "garba"), ("#dba6e8", "linear-gradient(160deg,#b862d6,#e85b9f)", "linear-gradient(135deg,#9b4fd0 50%,#ef7fb4 50%)")),
    (("tilak", "roka", "sagai", "engagement", "ring", "mangni"), ("#f6b27a", "linear-gradient(160deg,#ffb35c,#d9541e)", "linear-gradient(135deg,#f08a2c 50%,#c9362b 50%)")),
    (("reception", "walima", "valima", "bou bhaat", "party"), ("#c9a0b4", "linear-gradient(160deg,#a8466e,#4a1430)", "linear-gradient(135deg,#1e1a1c 50%,#b08a52 50%)")),
    (("shaadi", "wedding", "vivah", "vivaah", "nikah", "biye", "anand karaj", "kalyanam", "pheras", "lagan"), ("#e59aa6", "linear-gradient(160deg,#c02444,#6a0e25)", "linear-gradient(135deg,#b8213f 50%,#d9ad52 50%)")),
]
DEFAULT_LOOK = ("#e6cc93", "linear-gradient(160deg,#d9b56e,#8a6a35)", "linear-gradient(135deg,#b08a52 50%,#fcf7f5 50%)")
MAIN_WORDS = EVENT_LOOKS[-1][0]


def esc(s): return html.escape(str(s or ""), quote=True)


def look(ev):
    n = ev["name"].lower()
    for keys, lk in EVENT_LOOKS:
        if any(k in n for k in keys): return lk
    return DEFAULT_LOOK


def glyph_size(e):  # shrink long words so they stay inside the card art
    n = len(e.get("local") or e["name"])
    return f' style="font-size:{max(20, 44 * 9 // n)}px;text-align:center;padding:0 12px"' if n > 9 else ""


def day(d): return dt.date.fromisoformat(d)


def time24(t, default=(19, 0)):
    m = re.search(r"(\d{1,2})(?::(\d{2}))?\s*([ap])\.?m", str(t or ""), re.I)
    if not m: return default
    h = int(m[1]) % 12 + (12 if m[3].lower() == "p" else 0)
    return h, int(m[2] or 0)


def resize(src, dst, edge):
    dst.parent.mkdir(parents=True, exist_ok=True)
    try:
        from PIL import Image, ImageOps
        im = ImageOps.exif_transpose(Image.open(src))
        im.thumbnail((edge, edge))
        if dst.suffix == ".png": im.save(dst, optimize=True)
        else: im.convert("RGB").save(dst, quality=78, optimize=True, progressive=True)
        return
    except ImportError:
        pass
    shutil.copy(src, dst)
    if shutil.which("sips"):
        subprocess.run(["sips", "-Z", str(edge), "-s", "format", "png" if dst.suffix == ".png" else "jpeg", str(dst), "--out", str(dst)], capture_output=True)


def seal_svg(initials, theme):
    tok = dict(kv.split(":") for kv in theme["tokens"].split(";"))
    rose, wine, gold = tok["--rose"], tok["--wine"], tok["--gold-lt"]
    pts = []
    import math
    for i in range(36):  # wobbly wax edge
        a = i / 36 * 2 * math.pi; r = 92 + 5 * math.sin(i * 2.3) + 3 * math.cos(i * 5.1)
        pts.append(f"{100 + r * math.cos(a):.1f},{100 + r * math.sin(a):.1f}")
    fs = 64 if len(initials) <= 2 else 46
    return f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><defs><radialGradient id="w" cx="38%" cy="32%" r="75%"><stop offset="0" stop-color="{rose}"/><stop offset="1" stop-color="{wine}"/></radialGradient>
<filter id="e"><feGaussianBlur in="SourceAlpha" stdDeviation="1.2"/><feOffset dx="1.5" dy="2"/><feComposite in2="SourceAlpha" operator="arithmetic" k2="-1" k3="1"/><feColorMatrix values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 .55 0"/><feComposite in2="SourceGraphic" operator="over"/></filter></defs>
<polygon points="{' '.join(pts)}" fill="url(#w)"/><circle cx="100" cy="100" r="70" fill="none" stroke="{wine}" stroke-width="5" opacity=".55" filter="url(#e)"/>
<circle cx="100" cy="100" r="62" fill="none" stroke="{gold}" stroke-width="1.2" stroke-dasharray="2 5" opacity=".7"/>
<text x="100" y="{100 + fs * .34:.0f}" text-anchor="middle" font-family="Didot,'Bodoni 72',Georgia,serif" font-size="{fs}" letter-spacing="2" fill="{wine}" filter="url(#e)">{esc(initials)}</text>
<ellipse cx="72" cy="58" rx="26" ry="12" fill="#fff" opacity=".18" transform="rotate(-30 72 58)"/></svg>"""


def build(cfg, out, inline=False):
    theme = THEMES[cfg.get("theme", "royal-rose")]
    tname = cfg.get("theme", "royal-rose")
    events = cfg["events"]
    main = next((e for e in events if e.get("main")), None) or next((e for e in events if any(w in e["name"].lower() for w in MAIN_WORDS)), events[0])
    rec = next((e for e in events if e.get("reception")), None) or next((e for e in events if any(w in e["name"].lower() for w in EVENT_LOOKS[4][0])), None)
    tz = cfg.get("utc_offset", "+05:30")
    sign = -1 if tz[0] == "-" else 1; th, tm = map(int, tz[1:].split(":")); off = dt.timedelta(hours=th, minutes=tm) * sign
    d = day(main["date"]); hh, mm = time24(cfg.get("muhurat") or main.get("time"))
    start_local = dt.datetime(d.year, d.month, d.day, hh, mm)
    start_utc = start_local - off
    g, b = cfg["groom"], cfg["bride"]
    first, second = (b, g) if cfg.get("bride_first") else (g, b)
    l1, l2 = (cfg.get("bride_line", ""), cfg.get("groom_line", "")) if cfg.get("bride_first") else (cfg.get("groom_line", ""), cfg.get("bride_line", ""))
    couple = f"{first} & {second}"
    venue = cfg["venue"]
    vfull = ", ".join(x for x in (venue["name"], venue.get("address")) if x)
    maps = venue.get("maps") or "https://www.google.com/maps/search/?api=1&query=" + urllib.parse.quote(vfull)
    label = cfg.get("muhurat_label", "Pheras")
    when = f"{label} at {cfg.get('muhurat') or main.get('time', '')} · {venue['name']}".replace(" at  ·", " ·")
    cal = "https://calendar.google.com/calendar/render?" + urllib.parse.urlencode({
        "action": "TEMPLATE", "text": f"{couple}'s {main['name']}",
        "dates": f"{start_utc:%Y%m%dT%H%M%SZ}/{start_utc + dt.timedelta(hours=4):%Y%m%dT%H%M%SZ}",
        "details": when, "location": vfull})

    cards = []
    for e in events:
        tint, c1, c2 = look(e); ed = day(e["date"])
        chip = f'<div class="chip"><i></i><div><span>Dress code</span><b>{esc(e["dress"])}</b></div></div>' if e.get("dress") else ""
        cards.append(f'\n      <article class="card" data-tint="{tint}" style="--c1:{c1};--c2:{c2}"><div class="art"><svg class="mand"><use href="#mandala"/></svg><span class="glyph"{glyph_size(e)}>{esc(e.get("local") or e["name"])}</span></div>'
                     f'<div class="body"><div class="meta">{ed:%a} · {ed.day} {ed:%b}{" · " + esc(e["time"]) if e.get("time") else ""}</div><h3>{esc(e["name"])}</h3><div class="place">{esc(e.get("place") or venue["name"])}</div>{chip}</div></article>')

    photos = cfg.get("photos", {})
    story = photos.get("story") or []
    img = out / "img"; img.mkdir(parents=True, exist_ok=True)
    story_html = []
    for i, ph in enumerate(story[:6]):
        resize(Path(ph["src"]).expanduser(), img / f"story{i}.jpg", 1000)
        story_html.append(f'\n      <figure class="card" style="margin:0"><div class="ph" style="background-image:url(img/story{i}.jpg)"></div><p>{esc(ph.get("caption", ""))}</p></figure>')
    if not story_html:  # placeholders so the section never looks empty
        for f, cap in (("couple.jpg", "Just us two"), ("venue.jpg", "Where it all happens"), ("attire.jpg", "Dressed for forever")):
            story_html.append(f'\n      <figure class="card" style="margin:0"><div class="ph contain" style="background-image:url(img/{f});background-color:var(--pearl)"></div><p>{cap}</p></figure>')
        shutil.copy(ASSETS / "img/attire.jpg", img / "attire.jpg")

    reception = ""
    if rec:
        rd = day(rec["date"])
        reception = f"""  <section id="reception">
    <div class="stage" id="stage">
      <canvas class="lights" id="lights" aria-hidden="true"></canvas>
      <div class="valance"></div>
      <div class="rcard">
        <div class="eyebrow">You're invited to the</div>
        <h2 class="foil">{esc(rec.get("title") or "Grand " + rec["name"])}</h2>
        <div class="d">{rd:%A}, {rd.day} {rd:%B %Y}</div>
        <p>{esc(rec.get("time", ""))}{" onwards" if rec.get("time") else ""}{" · " + esc(rec["note"]) if rec.get("note") else ""}</p>
        <p>{esc(rec.get("place") or venue["name"])}</p>
        {f'<div class="dc">Dress code: {esc(rec["dress"])}</div>' if rec.get("dress") else ""}
      </div>
      <div class="cur l"></div><div class="cur r"></div>
    </div>
  </section>"""

    blessing = cfg.get("blessing") or theme["blessing"]
    mq = "".join(f"<span>{esc(x)}</span><em>✦</em>" for x in (blessing, couple, blessing, f"{d.day} {d:%B %Y}", blessing, venue.get("city") or venue["name"]))
    initials = cfg.get("initials") or (first[0] + second[0]).upper()

    # images: theme art, venue, couple photo, seal
    tdir = ASSETS / "themes" / tname
    if not tdir.exists(): tdir = ASSETS / "themes" / "royal-rose"
    for f in ("frame", "envelope", "curtain"):
        src = Path(cfg.get("images", {}).get(f, tdir / f"{f}.jpg")).expanduser()
        resize(src, img / f"{f}.jpg", 1100)
    resize(Path(photos.get("couple") or ASSETS / "img/couple.jpg").expanduser(), img / "couple.jpg", 900)
    resize(Path(photos.get("venue") or ASSETS / "img/palace.jpg").expanduser(), img / "venue.jpg", 1000)
    if photos.get("seal"):
        resize(Path(photos["seal"]).expanduser(), img / "seal.png", 600); seal = "img/seal.png"
    else:
        (img / "seal.svg").write_text(seal_svg(initials, theme), encoding="utf-8"); seal = "img/seal.svg"

    particles = {"petal": theme["petal"], "gold": ["#f7e3a6", "#e6cc93", "#d9ad52", "#fff4d0"], "heart": theme["heart"]}
    runtime = {"opening": cfg.get("opening", "ribbon"), "ribbonHue": cfg.get("ribbon_hue", theme["hue"]),
               "greeting": cfg.get("greeting") or theme["greeting"], "couple": couple,
               "whatsapp": re.sub(r"\D", "", str(cfg.get("rsvp", {}).get("whatsapp", ""))), "music": cfg.get("music", True)}
    inv = cfg.get("invocation", theme["invocation"])
    T = {
        "TITLE": esc(f"{first} weds {second}"), "INVOCATION": esc(inv), "COUPLE": esc(couple), "DATE_DOTS": f"{d.day:02d} · {d.month:02d} · {d.year}",
        "SEAL": seal, "NAME1": esc(first), "NAME2": esc(second), "LINE1": esc(l1), "LINE2": esc(l2),
        "DOW": f"{d:%A}", "DAY": str(d.day), "MONTH": f"{d:%B}", "YEAR": str(d.year), "WHEN": esc(when), "MAIN_LC": esc(label.lower()),
        "CAL_URL": esc(cal), "MARQUEE": mq * 2, "EVENTS": "".join(cards), "STORY": "".join(story_html), "RECEPTION": reception,
        "VENUE": esc(venue["name"]), "ADDRESS": esc(venue.get("address", "")), "MAPS_URL": esc(maps), "VENUE_FULL_JS": json.dumps(vfull, ensure_ascii=False),
        "RSVP_BY": esc(cfg.get("rsvp", {}).get("by", "")), "FAMILIES": esc(cfg.get("families", f"the families of {first} & {second}")),
        "PARTICLES": json.dumps(particles), "TARGET_MS": str(int(start_utc.replace(tzinfo=dt.timezone.utc).timestamp() * 1000)),
        "THEME_CSS": f":root{{{theme['tokens']}}}" + (DARK_GATE if theme.get("dark") else ""), "CFG_JSON": json.dumps(runtime, ensure_ascii=False),
    }
    s = (ASSETS / "template.html").read_text(encoding="utf-8")
    s = re.sub(r"\{\{([A-Z_0-9]+)\}\}", lambda m: T[m[1]], s)
    if not inv: s = s.replace('<div class="om"></div>', "").replace('<div class="om q"></div>', "")
    if not cfg.get("rsvp", {}).get("by"): s = re.sub(r'<p class="center"[^>]*>Please reply by </p>', "", s)
    if inline:
        def data(m):
            p = out / m[2]; mt = mimetypes.guess_type(p.name)[0] or "image/jpeg"
            return f"{m[1]}data:{mt};base64,{base64.b64encode(p.read_bytes()).decode()}"
        s = re.sub(r'(url\(|src=")(img/[\w.-]+)', data, s)
    (out / "index.html").write_text(s, encoding="utf-8")
    left = re.findall(r"\{\{[A-Z_]+\}\}", s)
    assert not left, left
    return out / "index.html"


if __name__ == "__main__":
    if len(sys.argv) < 3: sys.exit(__doc__)
    cfg = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    p = build(cfg, Path(sys.argv[2]), "--inline" in sys.argv)
    print(f"built {p} ({p.stat().st_size // 1024} KB)")
