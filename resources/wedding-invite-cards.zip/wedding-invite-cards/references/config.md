# invite.json

Only `groom`, `bride`, `venue.name` and `events` are required.

```json
{
  "groom": "Arjun",
  "bride": "Priya",
  "bride_first": false,
  "groom_line": "son of Mr. & Mrs. Sharma",
  "bride_line": "daughter of Mr. & Mrs. Verma",
  "families": "the Sharma & Verma families",
  "initials": "AP",

  "theme": "royal-rose",
  "opening": "ribbon",
  "music": true,
  "invocation": "॥ श्री गणेशाय नमः ॥",
  "greeting": "Namaste!",
  "blessing": "शुभ विवाह",

  "muhurat": "7:30 pm",
  "muhurat_label": "Pheras",
  "utc_offset": "+05:30",

  "venue": {
    "name": "Sunbagh Gardens",
    "address": "Civil Lines, Jaipur, Rajasthan",
    "city": "Jaipur",
    "maps": "https://maps.app.goo.gl/..."
  },

  "events": [
    {"name": "Haldi", "local": "हल्दी", "date": "2027-02-17", "time": "10:00 am", "place": "Garden Lawns", "dress": "Wear yellow"},
    {"name": "Shaadi", "local": "विवाह", "date": "2027-02-18", "time": "6:00 pm", "dress": "Red & gold", "main": true},
    {"name": "Reception", "date": "2027-02-20", "time": "8:00 pm", "place": "Rose Lawns", "dress": "Black tie", "note": "Dinner & dance"}
  ],

  "rsvp": {"whatsapp": "+91 98765 43210", "by": "1 February 2027"},

  "photos": {
    "couple": "/path/couple.jpg",
    "venue": "/path/venue.jpg",
    "seal": "/path/monogram.png",
    "story": [{"src": "/path/1.jpg", "caption": "Where we met"}]
  },
  "images": {"frame": "/path/frame.jpg", "envelope": "/path/envelope.jpg", "curtain": "/path/curtain.jpg"}
}
```

## Field notes

| Field | Meaning |
|---|---|
| `bride_first` | `true` puts the bride's name first everywhere (title, arch, RSVP text). |
| `*_line` | Line under each name. Leave `""` to hide. |
| `initials` | Letters on the generated wax seal. Defaults to first letters of both names. |
| `theme` | `royal-rose`, `temple-gold`, `bengal-red`, `phulkari`, `emerald-nikah`, `ivory-minimal`. |
| `opening` | `ribbon` (seal, doors, pull a satin ribbon tail to untie), `doors` (seal then doors, quickest), `scratch` (seal, doors, scratch a gold disc to reveal the date). |
| `music` | `false` removes the music button and nothing plays. |
| `invocation` | Line at the top. `""` hides it. Theme gives a default. |
| `greeting` | First word of the WhatsApp RSVP message. Theme gives a default. |
| `blessing` | Word repeated in the scrolling marquee. Theme gives a default. |
| `muhurat` | Main ceremony time; drives countdown and calendar. Falls back to the main event's `time`, then 7 pm. |
| `muhurat_label` | "Pheras", "Nikah", "Muhurtham", "Anand Karaj", "Ceremony"... |
| `utc_offset` | Time zone of the wedding, default India `+05:30`. |
| `venue.maps` | Google Maps share link. If missing, a search link is made from name + address. |
| `events[].local` | Big word on the card art (Devanagari/Bengali/Gurmukhi/Urdu or English). Defaults to `name`. |
| `events[].main` | The wedding ceremony. Auto-detected from names like Shaadi/Wedding/Nikah/Biye if absent. |
| `events[].reception` | Adds the curtain-stage section. Auto-detected from Reception/Walima/Bou Bhaat. |
| `events[].title` | Heading on the reception stage, default "Grand Reception". |
| `events[].place` | Defaults to the venue name. |
| `rsvp.whatsapp` | Digits with country code. Empty means WhatsApp asks the guest whom to send to. |
| `photos.couple` | Shown softly behind the names. Default is a neutral placeholder. |
| `photos.venue` | Map card background. |
| `photos.seal` | Their own seal/monogram PNG (transparent works best). Otherwise an SVG seal is drawn with `initials` in theme colours. |
| `photos.story` | Up to 6 photos for the Our Story carousel; placeholders if empty. |
| `images` | Override the theme's frame/envelope/curtain art. |

Card colours follow the function name: Haldi yellow, Mehendi green,
Sangeet/Cocktail purple, Tilak/Roka/Engagement saffron, Shaadi red,
Reception wine, anything else gold.
