# Themes

Each theme ships its own envelope, frame and curtain art (`assets/themes/<id>/`),
colour tokens, ribbon colour, particle colours, and defaults for the invocation,
RSVP greeting and marquee word. Any default can be overridden in the config.

| id | Look | Ribbon | Particles | Good for |
|---|---|---|---|---|
| `royal-rose` | Blush pink embossed lotus envelope, rose-gold foil, wine accents | pink satin | rose petals | North Indian / Rajasthani, the default |
| `temple-gold` | Deep maroon silk with gold zari, kolam, jasmine and bells | gold | jasmine | Tamil, Telugu, Kannada, Malayali weddings |
| `bengal-red` | White paper with red alpana, conch shells, lal-paar border | red | red & white petals | Bengali biye |
| `phulkari` | Hot magenta with orange/green phulkari embroidery, marigolds | marigold orange | marigold | Punjabi, Sikh, loud festive families |
| `emerald-nikah` | Emerald velvet, gold Islamic geometry, Mughal arch | gold | white & champagne petals | Nikah, Walima |
| `ivory-minimal` | Ivory cotton paper, fine gold eucalyptus line art, sage | sage | soft leaves | Modern / court / destination weddings |

## Openings

| `opening` | What the guest does | Feel |
|---|---|---|
| `ribbon` | Taps the seal, doors swing open, then drags a satin ribbon tail until the bow unties (a tap auto-pulls it) | Most tactile, about 6 s |
| `doors` | Taps the seal, doors swing open, straight into the names | Fast, about 3 s, best for older relatives |
| `scratch` | Taps the seal, doors open, scratches a gold-foil disc to reveal the date | Playful, works well for save-the-dates |

## Making a new theme

1. Generate three 9:16 images (any image model; prompts below work well):
   - **frame**: "Wedding invitation background, portrait. <material + colour> with <motifs> in the corners and a thin arch border around a large plain empty centre (60% of the image) for text. Tactile, soft light. No text, no people."
   - **envelope**: "Top-down flat view of a closed wedding envelope filling the entire portrait frame: four triangular flaps meeting at the exact centre, a plain empty circle at the centre for a wax seal. <material + colour + motifs>. No text, no seal, no people."
   - **curtain**: "<fabric + colour> stage curtain with <trim>, vertical folds filling the whole frame, warm light. No text, no people."
2. Save them as `assets/themes/<id>/{frame,envelope,curtain}.jpg`.
3. Add an entry to `THEMES` in `scripts/build_invite.py`: the ten colour tokens (paper, blush, pearl = light backgrounds; ink, mauve = text; rose, rose-lt, wine = accent; gold, gold-lt = foil; glow/glow2 = RGB of the light halo behind text), `hue` for the ribbon, `petal` and `heart` particle colours, and the three text defaults.

For a one-off look you don't need a new theme: pass `images` in the config and
the closest theme's colours.
