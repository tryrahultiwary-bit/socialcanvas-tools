# Animation patterns (GSAP on inline SVG)

All tweens go on the composition's single paused root timeline `tl`, at absolute seconds.

## Mover groups — never animate the placed transform

A character placed with `transform="translate(540,1200) scale(.8)"` loses its placement when
GSAP tweens that same element. Wrap the moving part in an inner group and animate that group:

```svg
<g transform="translate(540,1200) scale(.8)"><g id="hn-mv"> ...character... </g></g>
```

## Transform origin

Use `transformOrigin` relative to the element's own bounding box, and put it in BOTH the from
and to vars. `svgOrigin` drifted off-centre in renders; avoid it.

```js
tl.fromTo("#burst", {scale:0, transformOrigin:"50% 50%"},
                    {scale:1, transformOrigin:"50% 50%", duration:.5, ease:"back.out(2)"}, 12.66);
```

## Idle life (every visible character, whole scene)

```js
// breathe: chest/body scale from the feet
tl.fromTo("#hn-body", {scaleY:1, transformOrigin:"50% 100%"},
  {scaleY:1.025, transformOrigin:"50% 100%", duration:1.6, ease:"sine.inOut", yoyo:true, repeat:N}, t0);
// blink: eyelids are .lid paths at opacity 0; flash to 1 for 0.12 s every 2–4 s
tl.set("#hn .lid", {opacity:1}, t).set("#hn .lid", {opacity:0}, t + .12);
```

Fixed repeat counts only, computed from the scene length. No `repeat:-1`, no `Math.random()`
(renders must be deterministic; use a seeded offset per character for blink times).

## Lip-sync

Draw a closed mouth plus an open-mouth overlay `#{pid}-mo` at opacity 0. For each word the
character speaks (from words.txt), open on the word and close just before the next one:

```js
tl.set("#mk-mo", {opacity:1}, w.start).set("#mk-mo", {opacity:0}, Math.min(w.start + .18, next.start - .03));
```

Add a small head nod (rotate ±3°, origin at the neck) on the stressed word.

## Story action on the key word

Each scene gets ONE readable action timed to its key word: drop falls, fish gulps, lamps go out,
staff raised, tail wraps. Lead it by about 0.1 s so it lands on the syllable. Typical eases:
`power2.in` for falls, `back.out` for pops, `expo.out` for hits.

## Fire / glow

```js
tl.to(".flk", {scaleY:1.15, opacity:.85, transformOrigin:"50% 100%", duration:.18,
  yoyo:true, repeat:N, stagger:.07, ease:"sine.inOut"}, t0);
```

## Camera

Animate a wrapper `.cam` around the scene SVG: slow scale 1.06→1.2 plus a small x/y pan over the
shot, a 0.25 s punch-in (+6 % scale) on title hits, and a zoom-through crossfade (outgoing scales
up and fades, incoming scales down from 1.15) of about 0.6 s.

## Checks that caught real bugs

- Characters cut off at the frame edge: snapshot every scene, not just a few.
- Small figures read badly on phones: the main character should be ≥40 % of the frame height.
- Patch scripts that use string replace: assert each match exists, or edits silently miss.
