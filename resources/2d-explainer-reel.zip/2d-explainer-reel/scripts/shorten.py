"""Shorten a reel under 60 s: drop whole phrases from the voiceover, then speed up (pitch preserved).
remap() moves any original timestamp onto the short timeline - pass every shot/title/animation time through it.
Edit CUTS / SPEECH_END for your project, keep the full-length files as assets/words_full.txt and
assets/audio/voiceover_full.wav, then run from the project root:  python3 shorten.py
Writes assets/audio/voiceover.wav and assets/words.txt."""
import subprocess

TEMPO = 1.15        # never above ~1.15 or the voice sounds rushed
HOLD = 2.2          # end-card hold after the last word
SPEECH_END = 91.55  # original time of the end of the last word
# original-time ranges removed, [a, b): from just before the first cut word to just before the next kept word
CUTS = [
    (4.38, 9.58),   # example: a whole sentence
    (14.62, 18.44),
]


def kept():
    segs, t = [], 0.0
    for a, b in CUTS:
        if a > t:
            segs.append((t, a))
        t = max(t, b)
    segs.append((t, SPEECH_END))
    return segs


def remap(t):
    """Original seconds -> short-cut seconds. Times inside a cut snap to the next kept moment."""
    acc = 0.0
    for a, b in kept():
        if t < a:
            return round(acc / TEMPO, 3)
        if t <= b:
            return round((acc + t - a) / TEMPO, 3)
        acc += b - a
    return round(acc / TEMPO + (t - SPEECH_END), 3)   # past speech: real-time (end card)


def in_cut(t):
    return any(a <= t < b for a, b in CUTS)


SPEECH = remap(SPEECH_END)
TOTAL = round(SPEECH + HOLD, 3)


def apply(shots, titles, end_card):
    """Remap the build's shot list and title cards; drop what lost its line."""
    out_shots = []
    for i, (sid, img, start, cam, mote, punches) in enumerate(shots):
        nxt = shots[i + 1][2] if i + 1 < len(shots) else SPEECH_END
        a, b = remap(start), remap(nxt)
        if b - a < 0.5:
            continue
        out_shots.append((sid, img, a, cam, mote, [remap(p) for p in punches if not in_cut(p) and remap(p) < b - .3]))
    out_shots[0] = out_shots[0][:2] + (0.0,) + out_shots[0][3:]
    out_titles = []
    for tid, a, b, k, big, sub in titles:
        na, nb = remap(a), remap(b)
        if nb - na >= 1.0:
            out_titles.append((tid, na, nb, k, big, sub))
    return out_shots, out_titles, (SPEECH, TOTAL), TOTAL


def make_words():
    out = []
    for line in open("assets/words_full.txt", encoding="utf-8"):
        toks = []
        for tok in line.strip().split("|"):
            if tok.strip():
                w, t = tok.rsplit(" ", 1)
                if not in_cut(float(t)):
                    toks.append(f"{w} {remap(float(t)):.2f}")
        if toks:
            out.append("|".join(toks))
    open("assets/words.txt", "w", encoding="utf-8").write("\n".join(out) + "\n")


def make_audio():
    segs = kept()
    parts, labels = [], []
    for i, (a, b) in enumerate(segs):
        d = b - a
        parts.append(f"[0:a]atrim={a:.3f}:{b:.3f},asetpts=PTS-STARTPTS,afade=t=in:d=0.015,afade=t=out:st={d-0.02:.3f}:d=0.02[s{i}]")
        labels.append(f"[s{i}]")
    fc = ";".join(parts) + f";{''.join(labels)}concat=n={len(segs)}:v=0:a=1,atempo={TEMPO}[out]"
    subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", "assets/audio/voiceover_full.wav", "-filter_complex", fc,
                    "-map", "[out]", "-ar", "48000", "assets/audio/voiceover.wav"], check=True)


if __name__ == "__main__":
    make_audio()
    make_words()
    a, b = CUTS[0]
    assert remap(0) == 0 and remap(b) == round(a / TEMPO, 3) and remap((a + b) / 2) == remap(b)
    print(f"speech {SPEECH}s, total {TOTAL}s, {len(kept())} kept segments")
