---
name: 2d-explainer-reel
description: Make a 9:16 2D animated explainer reel (Instagram Reels, YouTube Shorts, TikTok) under 60 seconds from a voiceover, with every character and scene drawn in SVG code by Claude and animated with GSAP in HyperFrames. No AI image or video generators. Use when the user asks for a 2D animated reel, an animated story or mythology video, an explainer short, a "storybook" animation, or wants to turn a script or voiceover into an animated video.
---

# 2D Animated Explainer Reel

Turn a voiceover into a 1080×1920 animated reel under 60 s. Claude draws everything as SVG
in code (flat 2D storybook style), animates characters (breathing, blinking, lip-sync, one story
action per scene), adds kinetic titles, word-by-word captions and SFX, then renders with HyperFrames.

**Hard rule:** never use AI image/video tools (Higgsfield, Arcads, Pixa, Runway, etc.). All art is
SVG written by Claude. If the user asks for "AI images", confirm before breaking this rule.

## Needs

- Node.js + ffmpeg (`brew install node ffmpeg`), Google Chrome, Python 3.
- HyperFrames: load the `/hyperframes` skill and follow its composition contract.
- Word timings: `whisper-cli` (whisper.cpp) with a large model, or `npx hyperframes transcribe`.

## Workflow — stop for approval where marked ✋

1. **Script** (skip if the user has one). ≤140 words for ≤55 s. Hook in the first 3 s, one event
   per sentence, a few lines of dialogue, a one-line moral at the end. Write `SCRIPT.md` as a table:
   time | voiceover | visual | on-screen title. ✋
2. **Voiceover.** Put the user's recording at `assets/audio/voiceover.wav` (48 kHz). Get word
   timings into `assets/words.txt`: one sentence per line, `word start_seconds` tokens joined by `|`:
   `Hanuman 0.09|ji 0.54|aajeevan 0.72|brahmachari 1.17|the. 2.07`
   Check the timings against the audio. Constant background noise breaks silence detection, so
   always cut on word timings.
3. **Scene list.** One scene per sentence (split long ones). For each: id, start word/time, what
   we see, what moves on which word, title word(s), camera move. ✋
4. **Character kit.** Write `art.py` with one function per character returning an SVG `<g>`:
   `name(pid, expr, pose, ...)`. Render a character sheet PNG via headless Chrome and show it. ✋
5. **Scenes.** `drawn.py`: one function per scene returning a full 1080×1920 SVG (sky/set,
   characters placed with `translate() scale()`, props). Keep faces out of the bottom 20 %
   (platform UI) and the top 10 %.
6. **Animation.** Per scene, a function returning GSAP code placed at the scene's absolute times.
   See `references/animation.md` for the patterns that work: mover groups, breathing, blinking,
   lip-sync, flicker, pops and transform origins.
7. **Composition.** `build.py` generates `compositions/scenes.html` (inline SVG per scene plus
   slow camera push or pan, zoom-through crossfades about 0.6 s), `titles.html` (kicker + big word +
   sub, pop in on the key word), `captions.html` (2–3 words per group, active word gold).
   Put shared `<defs>` in one hidden `<svg width=0 height=0>`. Add short synthesized SFX
   (whoosh on cuts, boom on title hits) under the voiceover.
8. **Check.** `npx hyperframes check`, then `npx hyperframes snapshot --at <key seconds>` and
   look at the frames: is anything cut off at the edges, are characters too small, does the
   motion happen on the right word, can you read the text? Fix, then show the user. ✋
9. **Render.** `npx hyperframes render . --fps 30 --crf 16 -o renders/<Name>_1080x1920.mp4`,
   plus a share copy: `ffmpeg -i in.mp4 -vf scale=720:-2 -crf 23 -c:a copy out_720p.mp4`.

## Over 60 seconds?

Cut whole phrases first, then speed up by at most 1.15× (`atempo`, pitch preserved). Use
`scripts/shorten.py`: list the cut ranges (original seconds, from just before the first cut
word to just before the next kept word) and it writes the shortened `voiceover.wav` and
`words.txt`. It also gives `remap(t)`. Pass every timestamp through it (shots, titles,
punch-ins, and every literal time in the animation code, via a hook such as `T = remap`), so
nothing drifts out of sync. Listen to each splice point afterwards.

## Style defaults

Flat 2D storybook look: bold silhouettes, 2–3 tone gradients, soft radial glows, a deep
night/indigo base with saffron and gold accents (or whatever palette the user picks), and
Playfair-style display titles. The same character always has the same colours, crown,
weapon and proportions in every scene.
